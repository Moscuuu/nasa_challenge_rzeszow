READ_ME Geomorphology 0-1m Ancillary data. 

The Geomorphology 0-1m map was derived from both new and previously published mappings of ten periglacial and glacial landforms described in Morgan and Putzig et al. [2025]. The geomorphology consistency estimates were calculated using a modified version of Equation 6, incorporating the weighting scheme outlined in Table 1 of Morgan and Putzig et al [2025].

The landform naming and weighting scheme is as follows:

ExpCraters = Expanded Craters			[0.1]
Fill = Fill					[0.1]
Glacier = Glacial Deposits (LDA/LVF/CCF)	[0.75]
Mantled = Latitude Dependent Mantle		[0.1]
PedestalCraters = Pedestal Craters		[0.75]
Polygons = Polygons (HiRISE scale)		[1]
RMCraters = Ring Mold Craters			[0.1]
Scallop = Scalloped Terrain			[0.75]	
TerCraters = Terraced Craters			[0.1]
Textured = Textured Terrain			[0.1]

All the datafiles are GeoTiffs with the following properties:
Projection = simple cylindrical.
Pixel scale = 3000 m
Longitude = 0 - 360E
Latitude = -60 - 60N
Shape type: spherical
No data = -30

Citation
If using this dataset, please cite:

Morgan, G. A., Putzig, N. E., et al. (2025). Refined Mapping of Subsurface Water Ice on Mars to Support Future Missions. Planet. Sci. J. 6 29, DOI:10.3847/PSJ/ad9b24

